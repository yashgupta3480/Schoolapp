/**
 * Created by sony on 28-12-2015.
 */
public interface ActivityCommunicator {
    void passDataToActivity(int filtercolor);

}
